#!/bin/sh
rm /mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/actions.json
rm /mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/actions.txt

IP=$(ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1' | head -1)
TMPFILE=/mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/actions.txt
FILE=/mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/actions.json

cat << _EOF_ > $TMPFILE
{
  "system":[
  	{
      "title":"System",
      "script":"bus.('dlg.open', 'iframe', 'http://$IP/cgi-bin/about.cgi', 'System settings')",
      "icon":""
    },
	{
      "title":"APlayer/Radio",
      "script":"bus.('dlg.open', 'iframe', 'http://$IP:7778', 'Album Player')",
      "icon":""
    },
	{
      "title":"Roon/AP setting",
      "script":"bus.('dlg.open', 'iframe', 'http://$IP:7780', 'Roonbridge settings')",
      "icon":""
    },
	{
      "title":"Reboot",
      "script":"bus.('dlg.open', 'iframe', 'http://$IP/cgi-bin/main.cgi?ACTION=reboot', 'Reboot')",
      "icon":""
    },
	{
      "title":"Shutdown",
      "script":"bus.('dlg.open', 'iframe', 'http://$IP/cgi-bin/main.cgi?ACTION=shutdown', 'Shutdown')",
      "icon":""
    }
	
	]
}

_EOF_

sed 's/bus./bus.$emit/g' $TMPFILE > $FILE
