#!/bin/sh

cd /home/tc/apmenu
sudo ./apmenu
