#!/bin/sh

cd /home/tc/aprenderer
sudo ./ap2renderer
