#!/bin/sh

cd /home/tc/aplayer
sudo ./aplayer
