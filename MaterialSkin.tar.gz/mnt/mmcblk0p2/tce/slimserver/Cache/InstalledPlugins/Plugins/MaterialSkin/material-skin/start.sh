#!/bin/sh
ip="$(ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
echo $ip
sed "s/quanghao/$ip/g" /mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/prototype.json >/mnt/mmcblk0p2/tce/slimserver/prefs/material-skin/actions.json
                                                                                                                                                                         




